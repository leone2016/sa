package esb;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PayPalPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayPalPaymentApplication.class, args);
	}

}
