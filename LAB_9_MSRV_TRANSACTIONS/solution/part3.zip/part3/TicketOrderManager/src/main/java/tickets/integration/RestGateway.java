package tickets.integration;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.client.RestClient;
import tickets.service.CustomErrorType;
import tickets.service.PaymentDTO;
import tickets.service.SeatReservationDTO;
import tickets.service.TicketDTO;

@Component
public class RestGateway {
    public boolean reserveSeat(SeatReservationDTO seatReservationDTO) {
        RestClient restClient = RestClient.builder()
                .baseUrl("http://localhost:8083")
                .build();
        SeatReservationDTO reserveSeatResponse = restClient.post()
                .uri("/seats")
                .contentType(MediaType.APPLICATION_JSON)
                .body(seatReservationDTO)
                .retrieve()
                .body(SeatReservationDTO.class);
        if (reserveSeatResponse.status().equals("error")){
            System.out.println("Seat reservation for ticket with ticket number " + seatReservationDTO.ticketNumber() + " failed");
            return false;
        } else {
            System.out.println("Seat reservation ticket with ticket number " + seatReservationDTO.ticketNumber() + " succeeded");
            return true;
        }
    }

    public boolean payTicket(PaymentDTO paymentDTO) {
        RestClient restClient = RestClient.builder()
                .baseUrl("http://localhost:8084")
                .build();
        PaymentDTO paymentResponse = restClient.post()
                .uri("/payments")
                .contentType(MediaType.APPLICATION_JSON)
                .body(paymentDTO)
                .retrieve()
                .body(PaymentDTO.class);
        if (paymentResponse.status().equals("error")) {
            System.out.println("Payment for ticket with ticket number " + paymentDTO.ticketNumber() + " failed");
            return false;
        } else {
            System.out.println("Payment for ticket with ticket number " + paymentDTO.ticketNumber() + " succeeded");
            return true;
        }
    }

    public boolean createTicket(TicketDTO ticketDTO) {
        RestClient restClient = RestClient.builder()
                .baseUrl("http://localhost:8085")
                .build();
        TicketDTO createTicketResponse = restClient.post()
                .uri("/tickets")
                .contentType(MediaType.APPLICATION_JSON)
                .body(ticketDTO)
                .retrieve()
                .body(TicketDTO.class);
        if (createTicketResponse.status().equals("error")) {
            System.out.println("Creating a ticket with ticket number " + ticketDTO.ticketNumber() + " failed");
            return false;
        } else {
            System.out.println("Creating a ticket with ticket number " + ticketDTO.ticketNumber() + " succeeded");
            return true;
        }
    }


    public void cancelSeatReservation(String ticketNumber) {
        RestClient restClient = RestClient.builder()
                .baseUrl("http://localhost:8083")
                .build();

        SeatReservationDTO cancelSeatResponse = restClient.put()
                .uri("/seats/" + ticketNumber)
                .retrieve()
                .body(SeatReservationDTO.class);
        System.out.println("Seat reservation with ticket number " + ticketNumber + " is cancelled");
    }

    public void refundTicket(String ticketNumber) {
        RestClient restClient = RestClient.builder()
                .baseUrl("http://localhost:8084")
                .build();
        PaymentDTO refundPaymentDTO = restClient.put()
                .uri("/payments/" + ticketNumber)
                .retrieve()
                .body(PaymentDTO.class);
        System.out.println("Ticket with ticket number " + ticketNumber + " is refunded");
    }
}
