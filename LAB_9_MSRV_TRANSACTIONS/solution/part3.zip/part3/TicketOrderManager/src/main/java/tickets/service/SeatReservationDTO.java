package tickets.service;

public record SeatReservationDTO(String ticketNumber, String flightNumber, String seatNumber, String status ) {}

