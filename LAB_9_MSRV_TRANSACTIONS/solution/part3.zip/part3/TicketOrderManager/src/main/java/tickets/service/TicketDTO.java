package tickets.service;

public record TicketDTO(String ticketNumber, String customerName, String status ) {}

