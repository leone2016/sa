package tickets.service;

import org.springframework.stereotype.Service;
import tickets.integration.RestGateway;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class TicketOrderManagerService {
    @Autowired
    private RestGateway restGateway;

    public void orderTicket(TicketOrderDTO ticketOrderDTO) {
        System.out.println("---------------------------------------Ticket ordering for ticket with number "+ticketOrderDTO.ticketNumber());

        SeatReservationDTO seatReservationDTO = new SeatReservationDTO(ticketOrderDTO.ticketNumber(), ticketOrderDTO.flightNumber(), ticketOrderDTO.seatNumber(), ticketOrderDTO.ticketstatus());
        boolean isSeatReserved = restGateway.reserveSeat(seatReservationDTO);

        if (isSeatReserved) {
            PaymentDTO paymentDTO = new PaymentDTO(ticketOrderDTO.ticketNumber(), ticketOrderDTO.amount(), ticketOrderDTO.paystatus());
            boolean isTicketPaid = restGateway.payTicket(paymentDTO);
            if (!isTicketPaid) {
                System.out.println("-------------------------rollback ticket reservation");
                //rollback ticket reservation
                restGateway.cancelSeatReservation(ticketOrderDTO.ticketNumber());
            } else {
                TicketDTO ticketDTO = new TicketDTO(ticketOrderDTO.ticketNumber(), ticketOrderDTO.customerName(), ticketOrderDTO.ticketstatus());
                boolean isTicketCreated = restGateway.createTicket(ticketDTO);
                if (!isTicketCreated) {
                    System.out.println("-------------------------rollback ticket reservation and payment");
                    //rollback ticket reservation and payment
                    restGateway.cancelSeatReservation(ticketOrderDTO.ticketNumber());
                    restGateway.refundTicket(ticketOrderDTO.ticketNumber());
                }
            }
        }
    }

}
