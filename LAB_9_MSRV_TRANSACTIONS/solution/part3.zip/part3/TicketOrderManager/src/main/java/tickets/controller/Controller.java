package tickets.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tickets.service.TicketOrderDTO;
import tickets.service.TicketOrderManagerService;

@RestController
public class Controller {

    @Autowired
    private TicketOrderManagerService ticketOrderManagerService;

    @PostMapping("/ticketorder")
    public ResponseEntity<?> payTicket(@RequestBody TicketOrderDTO ticketOrderDTO){
        ticketOrderManagerService.orderTicket(ticketOrderDTO);
        return new ResponseEntity<>(ticketOrderDTO,HttpStatus.OK);
    }

}
