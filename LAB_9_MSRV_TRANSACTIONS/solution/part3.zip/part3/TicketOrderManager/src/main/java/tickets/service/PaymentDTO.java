package tickets.service;

public record PaymentDTO(String ticketNumber, String amount, String status ) {}

