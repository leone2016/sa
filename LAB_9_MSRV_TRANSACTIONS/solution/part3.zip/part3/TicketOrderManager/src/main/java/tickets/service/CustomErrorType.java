package tickets.service;

public record CustomErrorType(String message) {

}
