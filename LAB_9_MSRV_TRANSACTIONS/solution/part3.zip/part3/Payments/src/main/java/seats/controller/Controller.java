package seats.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import seats.service.PaymentDTO;
import seats.service.PaymentsService;

import java.util.Random;

@RestController
public class Controller {

    @Autowired
    private PaymentsService paymentsService;

    @PostMapping("/payments")
    public ResponseEntity<PaymentDTO> payTicket(@RequestBody PaymentDTO paymentDTO){
        PaymentDTO returnValue;
        int randomNumber = new Random().nextInt(3);
        if(randomNumber == 1){
            returnValue = new PaymentDTO(paymentDTO.ticketNumber(), paymentDTO.amount(), "error");
        }
        else{
            returnValue = new PaymentDTO(paymentDTO.ticketNumber(), paymentDTO.amount(), "paid");
        }

        paymentsService.payTicket(returnValue);
        return new ResponseEntity<>(returnValue,HttpStatus.OK);
    }

    @PutMapping("/payments/{ticketNumber}")
    public ResponseEntity<?> refundTicket(@PathVariable String ticketNumber){
        PaymentDTO paymentDTO = paymentsService.refundTicket(ticketNumber);
        return new ResponseEntity<>(paymentDTO,HttpStatus.OK);
    }
}
