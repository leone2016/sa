package seats.service;

import org.springframework.stereotype.Service;
import seats.domain.Payment;
import seats.repository.PaymentsRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class PaymentsService {
    @Autowired
    private PaymentsRepository paymentsRepository;

    public void payTicket(PaymentDTO paymentDTO) {
        Payment payment = new Payment(paymentDTO.ticketNumber(), paymentDTO.amount(), paymentDTO.status());
        paymentsRepository.save(payment);
        System.out.println("save payment :"+payment);
    }

    public PaymentDTO refundTicket(String ticketNumber) {
        Payment payment = paymentsRepository.findById(ticketNumber).get();
        payment.setStatus("refunded");
        paymentsRepository.save(payment);
        return new PaymentDTO(payment.getTicketNumber(), payment.getAmount(), payment.getStatus());
    }

}
