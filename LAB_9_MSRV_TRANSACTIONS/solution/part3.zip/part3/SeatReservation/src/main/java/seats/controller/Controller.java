package seats.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import seats.service.SeatReservationDTO;
import seats.service.SeatService;

import java.util.Random;

@RestController
public class Controller {

    @Autowired
    private SeatService seatService;

    @PostMapping("/seats")
    public ResponseEntity<SeatReservationDTO> reserveSeat(@RequestBody SeatReservationDTO seatReservationDTO){
        SeatReservationDTO returnValue;
        int randomNumber = new Random().nextInt(5);
        if(randomNumber == 1){
            returnValue = new SeatReservationDTO(seatReservationDTO.ticketNumber(), seatReservationDTO.flightNumber(), seatReservationDTO.seatNumber(), "error");
        }
        else{
            returnValue = new SeatReservationDTO(seatReservationDTO.ticketNumber(), seatReservationDTO.flightNumber(), seatReservationDTO.seatNumber(), "reserved");
        }
        seatService.reserveSeat(returnValue);
        return new ResponseEntity<SeatReservationDTO>(returnValue,HttpStatus.OK);
    }

    @PutMapping("/seats/{ticketNumber}")
    public ResponseEntity<?> cancelReservation(@PathVariable String ticketNumber){
        SeatReservationDTO seatReservationDTO = seatService.cancelSeatReservation(ticketNumber);
        return new ResponseEntity<>(seatReservationDTO,HttpStatus.OK);
    }
}
