package seats.domain;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class SeatReservation {
    @Id
    private String ticketNumber;
    private String flightNumber;
    private String seatNumber;

    private String status;


    public SeatReservation(){}

    public SeatReservation(String ticketNumber, String flightNumber, String seatNumber, String status) {
        this.ticketNumber = ticketNumber;
        this.flightNumber = flightNumber;
        this.seatNumber = seatNumber;
        this.status = status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "SeatReservation{" +
                "ticketNumber='" + ticketNumber + '\'' +
                ", flightNumber='" + flightNumber + '\'' +
                ", seatNumber='" + seatNumber + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public String getStatus() {
        return status;
    }
}
