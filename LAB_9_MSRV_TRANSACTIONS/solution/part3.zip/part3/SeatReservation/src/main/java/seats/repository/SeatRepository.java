package seats.repository;

import seats.domain.SeatReservation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface SeatRepository extends MongoRepository<SeatReservation,String > {

}

