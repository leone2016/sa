package service;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClient;
import org.springframework.web.reactive.function.client.WebClient;


@SpringBootApplication
public class Client implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Client.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		sendTicketOrder(new TicketOrderDTO("1000", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1001", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1002", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1003", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1004", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1005", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1006", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1007", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1008", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1009", "John Doe", "", "560.00", "", "AA451", "34E", ""));

	}

	public void sendTicketOrder(TicketOrderDTO ticketOrderDTO){
		RestClient restClient = RestClient.builder()
				.baseUrl("http://localhost:8082/")
				.build();

		restClient.post()
				.uri("/ticketorder")
				.contentType(MediaType.APPLICATION_JSON)
				.body(ticketOrderDTO)
				.retrieve()
				.body(TicketOrderDTO.class);
	}

}
