package seats.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import seats.service.TicketDTO;
import seats.service.TicketService;

import java.util.Random;

@RestController
public class Controller {

    @Autowired
    private TicketService ticketService;

    @PostMapping("/tickets")
    public ResponseEntity<TicketDTO> createTicket(@RequestBody TicketDTO ticketDTO){
        TicketDTO returnValue;
        int randomNumber = new Random().nextInt(2);
        if(randomNumber == 1){
            returnValue = new TicketDTO(ticketDTO.ticketNumber(), ticketDTO.customerName(), "error");
        }
        else{
            returnValue = new  TicketDTO(ticketDTO.ticketNumber(), ticketDTO.customerName(), "created");
        }
        ticketService.createTicket(returnValue);
        return new ResponseEntity<TicketDTO>(returnValue,HttpStatus.OK);
    }

}
