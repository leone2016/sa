package seats.service;

import org.springframework.stereotype.Service;
import seats.domain.Ticket;
import seats.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class TicketService {
    @Autowired
    private TicketRepository ticketRepository;

    public void createTicket(TicketDTO ticketDTO) {
        Ticket ticket = new Ticket(ticketDTO.ticketNumber(), ticketDTO.customerName(), ticketDTO.status());
        ticketRepository.save(ticket);
    }

}
