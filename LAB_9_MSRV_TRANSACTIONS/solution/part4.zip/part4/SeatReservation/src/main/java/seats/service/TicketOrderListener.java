package seats.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import seats.integration.MessageSender;
import java.util.Random;


@Component
public class TicketOrderListener {

    @Autowired
    SeatService seatService;
    @Autowired
    MessageSender messageSender;

    @KafkaListener(topics = "TicketOrderTopic")
    public void receiveMessage(final String ticketOrderAsString) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            TicketOrderDTO ticketOrderDTO = objectMapper.readValue(ticketOrderAsString, TicketOrderDTO.class);
            SeatReservationDTO seatReservationDTO;
            int randomNumber = new Random().nextInt(5);

            if(randomNumber == 1){
                seatReservationDTO = new SeatReservationDTO(ticketOrderDTO.getTicketNumber(), ticketOrderDTO.getFlightNumber(), ticketOrderDTO.getSeatNumber(), "error");
                ticketOrderDTO.setSeatstatus("error");
                System.out.println("Seat reservation with ticket number " + ticketOrderDTO.getTicketNumber() + " failed");
            }
            else{
                seatReservationDTO = new SeatReservationDTO(ticketOrderDTO.getTicketNumber(), ticketOrderDTO.getFlightNumber(), ticketOrderDTO.getSeatNumber(), "reserved");
                ticketOrderDTO.setSeatstatus("reserved");
                System.out.println("Seat reservation with ticket number " + ticketOrderDTO.getTicketNumber() + " succeeded");
            }
            seatService.reserveSeat(seatReservationDTO);
            messageSender.sendMessage(ticketOrderDTO);

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    @KafkaListener(topics = {"TicketTopic", "PaymentTopic"})
    public void receiveTicketCreationMessage(final String ticketOrderAsString) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            TicketOrderDTO ticketOrderDTO = objectMapper.readValue(ticketOrderAsString, TicketOrderDTO.class);
            if (ticketOrderDTO.getTicketstatus().equals("error") || ticketOrderDTO.getPaystatus().equals("error")){
                seatService.cancelSeatReservation(ticketOrderDTO.getTicketNumber());
                System.out.println("Seat reservation with ticket number " + ticketOrderDTO.getTicketNumber() + " is cancelled");
            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
