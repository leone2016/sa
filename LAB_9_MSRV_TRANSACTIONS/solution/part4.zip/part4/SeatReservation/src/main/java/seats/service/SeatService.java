package seats.service;

import org.springframework.stereotype.Service;
import seats.domain.SeatReservation;
import seats.integration.MessageSender;
import seats.repository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class SeatService {
    @Autowired
    private SeatRepository seatRepository;

    public void reserveSeat(SeatReservationDTO seatReservationDTO) {
        SeatReservation seatReservation = new SeatReservation(seatReservationDTO.ticketNumber(), seatReservationDTO.flightNumber(), seatReservationDTO.seatNumber(),seatReservationDTO.status());
        seatRepository.save(seatReservation);
    }

    public SeatReservationDTO cancelSeatReservation(String ticketNumber) {
        SeatReservation seatReservation = seatRepository.findById(ticketNumber).get();
        seatReservation.setStatus("canceled");
        seatRepository.save(seatReservation);
        return new SeatReservationDTO(seatReservation.getTicketNumber(), seatReservation.getFlightNumber(), seatReservation.getSeatNumber(), seatReservation.getStatus());
    }

}
