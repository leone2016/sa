package client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Client implements CommandLineRunner {
	@Autowired
	MessageSender messageSender;

	public static void main(String[] args) {
		SpringApplication.run(Client.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		sendTicketOrder(new TicketOrderDTO("1000", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1001", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1002", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1003", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1004", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1005", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1006", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1007", "John Doe", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1008", "Frank Brown", "", "560.00", "", "AA451", "34E", ""));
		sendTicketOrder(new TicketOrderDTO("1009", "John Doe", "", "560.00", "", "AA451", "34E", ""));

	}

	public void sendTicketOrder(TicketOrderDTO ticketOrderDTO){
		messageSender.sendMessage(ticketOrderDTO);
	}

}
