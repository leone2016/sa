package client;

public record TicketOrderDTO(String ticketNumber,
                             String customerName,
                             String ticketstatus,
                             String amount,
                             String paystatus,
                             String flightNumber,
                             String seatNumber,
                             String seatstatus
                             ) {}

