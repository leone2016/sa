package seats.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import seats.integration.MessageSender;

import java.util.Random;


@Component
public class TicketOrderListener {

    @Autowired
    PaymentsService paymentsService;
    @Autowired
    MessageSender messageSender;

    @KafkaListener(topics = "SeatReservationTopic")
    public void receiveSeatReservationMessage(final String ticketOrderAsString) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            TicketOrderDTO ticketOrderDTO = objectMapper.readValue(ticketOrderAsString, TicketOrderDTO.class);
            if (ticketOrderDTO.getSeatstatus().equals("reserved")){
                PaymentDTO paymentDTO;
                int randomNumber = new Random().nextInt(5);

                if(randomNumber == 1){
                    paymentDTO = new PaymentDTO(ticketOrderDTO.getTicketNumber(), ticketOrderDTO.getAmount(), "error");
                    ticketOrderDTO.setPaystatus("error");
                    System.out.println("Payment for  ticket number " + ticketOrderDTO.getTicketNumber() + " failed");
                }
                else{
                    paymentDTO = new PaymentDTO(ticketOrderDTO.getTicketNumber(), ticketOrderDTO.getAmount(),  "paid");
                    ticketOrderDTO.setPaystatus("paid");
                    System.out.println("Payment for  ticket number " + ticketOrderDTO.getTicketNumber() + " succeeded");
                    paymentsService.payTicket(paymentDTO);
                }

                messageSender.sendMessage(ticketOrderDTO);
            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    @KafkaListener(topics = "TicketTopic")
    public void receiveTicketCreationMessage(final String ticketOrderAsString) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            TicketOrderDTO ticketOrderDTO = objectMapper.readValue(ticketOrderAsString, TicketOrderDTO.class);
            if (ticketOrderDTO.getTicketstatus().equals("error")){
                paymentsService.refundTicket(ticketOrderDTO.getTicketNumber());
                System.out.println("Payment for  ticket number " + ticketOrderDTO.getTicketNumber() + " is refunded");
            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
