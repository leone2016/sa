package seats.service;

public class TicketOrderDTO {
    private String ticketNumber;
    private String customerName;
    private String ticketstatus;
    private String amount;
    private String paystatus;
    private String flightNumber;
    private String seatNumber;
    private String seatstatus;

    public TicketOrderDTO() {
    }

    public TicketOrderDTO(String ticketNumber, String customerName, String ticketstatus, String amount, String paystatus, String flightNumber, String seatNumber, String seatstatus) {
        this.ticketNumber = ticketNumber;
        this.customerName = customerName;
        this.ticketstatus = ticketstatus;
        this.amount = amount;
        this.paystatus = paystatus;
        this.flightNumber = flightNumber;
        this.seatNumber = seatNumber;
        this.seatstatus = seatstatus;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTicketstatus() {
        return ticketstatus;
    }

    public void setTicketstatus(String ticketstatus) {
        this.ticketstatus = ticketstatus;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPaystatus() {
        return paystatus;
    }

    public void setPaystatus(String paystatus) {
        this.paystatus = paystatus;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public String getSeatstatus() {
        return seatstatus;
    }

    public void setSeatstatus(String seatstatus) {
        this.seatstatus = seatstatus;
    }
}


