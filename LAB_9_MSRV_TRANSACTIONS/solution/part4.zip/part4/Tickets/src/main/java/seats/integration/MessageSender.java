package seats.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import seats.service.TicketOrderDTO;

@Component
public class MessageSender {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;


    public void sendMessage(TicketOrderDTO ticketOrderDTO)  {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String eventString = objectMapper.writeValueAsString(ticketOrderDTO);
            System.out.println("Sending a Kafka message:" + eventString);
            kafkaTemplate.send("TicketTopic", eventString);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
