package seats.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import seats.integration.MessageSender;

import java.util.Random;


@Component
public class TicketOrderListener {

    @Autowired
    TicketService ticketService;

    @Autowired
    MessageSender messageSender;

    @KafkaListener(topics = "PaymentTopic")
    public void receiveMessage(final String ticketOrderAsString) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            TicketOrderDTO ticketOrderDTO = objectMapper.readValue(ticketOrderAsString, TicketOrderDTO.class);
            if (ticketOrderDTO.getPaystatus().equals("paid")){
                TicketDTO ticketDTO;
                int randomNumber = new Random().nextInt(2);

                if(randomNumber == 1){
                    ticketDTO = new TicketDTO(ticketOrderDTO.getTicketNumber(), ticketOrderDTO.getCustomerName(), "error");
                    ticketOrderDTO.setTicketstatus("error");
                    System.out.println("Creating a ticket for  ticket number " + ticketOrderDTO.getTicketNumber() + " failed");
                    messageSender.sendMessage(ticketOrderDTO);
                }
                else{
                    ticketDTO = new TicketDTO(ticketOrderDTO.getTicketNumber(), ticketOrderDTO.getCustomerName(),  "created");
                    ticketOrderDTO.setTicketstatus("created");
                    System.out.println("Creating a ticket for  ticket number " + ticketOrderDTO.getTicketNumber() + " succeeded");
                    ticketService.createTicket(ticketDTO);
                }

            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
