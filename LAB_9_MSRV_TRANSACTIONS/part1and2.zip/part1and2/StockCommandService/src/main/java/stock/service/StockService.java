package stock.service;

public interface StockService {
    void add(StockDTO stockDTO);
    void delete(String product_id);
    void update(String productId,StockDTO stockDTO);
}
