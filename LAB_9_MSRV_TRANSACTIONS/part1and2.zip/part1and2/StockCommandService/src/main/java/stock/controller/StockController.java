package stock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import stock.service.StockDTO;
import stock.service.StockService;

@RestController
public class StockController {
    @Autowired
    private StockService stockService;


    @PostMapping("/stocks")
    public ResponseEntity<?> add(@RequestBody StockDTO stockDTO){
        System.out.println("Add stock "+ stockDTO);
        stockService.add(stockDTO);
        return new ResponseEntity<>(stockDTO, HttpStatus.OK);
    }

    @PutMapping("/stocks/{product_id}")
    public ResponseEntity<?> update(@PathVariable String product_id,@RequestBody StockDTO stockDTO){
        stockService.update(product_id, stockDTO);
        return new ResponseEntity<>(stockDTO,HttpStatus.OK);
    }

    @DeleteMapping("/stocks/{product_id}")
    public ResponseEntity<?> delete(@PathVariable String product_id){
        stockService.delete(product_id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
