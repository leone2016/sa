package stock.service;

public class StockUpdateEventHandler {
    public static void handle(String product_id, StockDTO stockDTO){

    }
}
