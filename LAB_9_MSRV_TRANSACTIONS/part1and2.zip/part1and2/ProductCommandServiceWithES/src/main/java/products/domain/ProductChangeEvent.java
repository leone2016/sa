package products.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ProductChangeEvent {

    private String change;
    private Product product;

    public ProductChangeEvent() {
    }

    public ProductChangeEvent(String change, Product product) {
        this.change = change;
        this.product = product;
    }

    public String getChange() {
        return change;
    }

    public Product getProduct() {
        return product;
    }
}
