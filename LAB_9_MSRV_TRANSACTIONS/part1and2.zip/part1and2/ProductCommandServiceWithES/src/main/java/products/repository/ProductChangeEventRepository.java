package products.repository;

import products.domain.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import products.domain.ProductChangeEvent;

import java.util.Optional;

@Repository
public interface ProductChangeEventRepository extends MongoRepository<ProductChangeEvent,Long > {

}

