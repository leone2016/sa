package productqueryservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import productqueryservice.data.ProductRepository;
import productqueryservice.domain.Product;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    private ProductRepository productRepository;

    @Override
    public void add(ProductDTO productDTO) {
        Product product = ProductAdapter.fromDTO(productDTO);
        productRepository.save(product);
    }

    @Override
    public void delete(String productId) {
        productRepository.deleteById(productId);
    }

    @Override
    public void update(String productId, ProductDTO productDTO) {
        Optional<Product> optionalProduct = productRepository.findById(productId);
        if(optionalProduct.isPresent()){
            Product product = optionalProduct.get();
            product.setName(productDTO.getName());
            product.setPrice(productDTO.getPrice());
            product.setNumberInStock(productDTO.getNumberInStock());
            productRepository.save(product);
        }
    }


    @Override
    public ProductDTO get(String productId) {
        Optional<Product> optionalProduct = productRepository.findById(productId);
        if(optionalProduct.isPresent()){
            Product product = optionalProduct.get();
            return ProductAdapter.toDTO(product);
        }
        return null;
    }

    @Override
    public void handle(ProductChangeEventDTO productChangeEventDTO) {
        if (productChangeEventDTO.getChange().equals("add")){
            add(productChangeEventDTO.getProduct());
        } else if (productChangeEventDTO.getChange().equals("delete")){
           delete(productChangeEventDTO.getProduct().getProductNumber());
        }
        else if (productChangeEventDTO.getChange().equals("update")){
            //first get the product
            int quantity=0;
            Optional<Product> optionalProduct = productRepository.findById(productChangeEventDTO.getProduct().getProductNumber());
            if(optionalProduct.isPresent()){
                Product product = optionalProduct.get();
                quantity=product.getNumberInStock();
            }

            update(productChangeEventDTO.getProduct().getProductNumber(),
                    new ProductDTO(productChangeEventDTO.getProduct().getProductNumber(),
                            productChangeEventDTO.getProduct().getName(),
                            productChangeEventDTO.getProduct().getPrice(),
                            quantity));
        }
    }

    @Override
    public void handle(StockChangeEventDTO stockChangeEventDTO) {
        Optional<Product> optionalProduct = productRepository.findById(stockChangeEventDTO.getProductId());
        if(optionalProduct.isPresent()){
            Product product = optionalProduct.get();
            product.setNumberInStock(stockChangeEventDTO.getNumberInStock());
            System.out.println("Updating stock: "+product.getProductNumber()+" , quantity = "+stockChangeEventDTO.getNumberInStock());
            productRepository.save(product);
        }
    }


}
