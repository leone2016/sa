package productqueryservice.service;


public interface ProductService {
    void add(ProductDTO productDTO);
    void delete(String productId);
    void update(String productId,ProductDTO productDTO);
    ProductDTO get(String productId);

    void handle(ProductChangeEventDTO productChangeEventDTO);
    void handle(StockChangeEventDTO stockChangeEventDTO);
}
