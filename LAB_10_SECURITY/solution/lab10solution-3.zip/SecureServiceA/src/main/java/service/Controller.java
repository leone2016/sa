package service;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
public class Controller {
	
	@GetMapping("/product")
	public String getProduct() {
		return "Apple MacBook Pro";
	}
	
	@GetMapping("/employee")
	@PreAuthorize("hasRole('MANAGER') || hasRole('EMPLOYEE')")
	public String getEmployee(@AuthenticationPrincipal Jwt jwt) {
		String token = jwt.getTokenValue();
		WebClient webClient = WebClient.builder()
				.baseUrl("http://localhost:8096")
				.build();
		// Call the downstream application with the same token
		String response = webClient.get()
				.uri("/employee")
				.headers(headers -> headers.setBearerAuth(token))
				.retrieve()
				.bodyToMono(String.class)
				.block();

		return response;	}
	
	@GetMapping("/salary")
	@PreAuthorize("hasRole('MANAGER')")
	public String getSalary(@AuthenticationPrincipal Jwt jwt) {
		String token = jwt.getTokenValue();
		WebClient webClient = WebClient.builder()
				.baseUrl("http://localhost:8097")
				.build();
		// Call the downstream application with the same token
		String response = webClient.get()
				.uri("/salary")
				.headers(headers -> headers.setBearerAuth(token))
				.retrieve()
				.bodyToMono(String.class)
				.block();

		return response;
	}

	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/sensitive")
	public String getPrivateData(@AuthenticationPrincipal Jwt jwt) {
		String token = jwt.getTokenValue();
		WebClient webClient = WebClient.builder()
				.baseUrl("http://localhost:8082")
				.build();
		// Call the downstream application with the same token
		String response = webClient.get()
				.uri("/private")
				.headers(headers -> headers.setBearerAuth(token))
				.retrieve()
				.bodyToMono(String.class)
				.block();

		return response;
	}
}
