package service;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@GetMapping("/salary")
	@PreAuthorize("hasRole('MANAGER')")
	public String getEmployeeInfo() {
		return "90.000";
	}
}
