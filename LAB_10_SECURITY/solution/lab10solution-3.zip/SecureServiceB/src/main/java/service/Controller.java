package service;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@GetMapping("/employee")
	@PreAuthorize("hasRole('MANAGER') || hasRole('EMPLOYEE')")
	public String getEmployeeInfo() {
		return "John Doe, phone: 061234567, email jdoe@gmail.com";
	}
}
