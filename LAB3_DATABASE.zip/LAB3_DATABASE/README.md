# LAB 3: DATA BASE

1. A zip file of part 1 **[ATTACHED](./part_1_Lesson3SpringMongoDemo.zip)**

2. A screenshot of part 2

   1. ![part 2](./assets/part_2.png)

3. Multiple screenshots of part 3

   1. Find all persons who own a Volvo car

      ![part3 1](./assets/part_3_1.png)

   2. Find the Car that is driven by Dan

      ![part3 1](./assets/part_3_2.png)

   3. Find all persons who love someone that owns a car.

      ![part3 1](./assets/part_3_3.png)

   4. Find who works at which company

   5. Find all people who work at NeoTech

   6. Find all people who Alice knows

      ![part3 1](./assets/part_3_4_all.png)

      

4. A PDF of part 4 **[ATTACHED](./part_4.pdf)**

