package esb;

public enum PaymentType {
    VISA,
    MASTERCARD,
    PAYPAL
}
