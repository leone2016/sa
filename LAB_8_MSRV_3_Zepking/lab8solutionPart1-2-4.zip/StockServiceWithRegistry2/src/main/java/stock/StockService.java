package stock;

import org.springframework.stereotype.Service;

@Service
public class StockService {
	
	public int getNumberOnStock(String productNumber) {
		return 13;
	}

}
