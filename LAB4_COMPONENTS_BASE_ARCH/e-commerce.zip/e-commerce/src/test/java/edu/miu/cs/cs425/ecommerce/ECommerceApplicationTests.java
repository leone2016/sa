package edu.miu.cs.cs425.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceApplicationTests {

    @Test
    void contextLoads() {
    }

}
