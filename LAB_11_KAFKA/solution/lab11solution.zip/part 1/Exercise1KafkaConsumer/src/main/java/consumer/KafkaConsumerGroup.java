package consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class KafkaConsumerGroup {

    @KafkaListener(topics = "new-order-topic", groupId = "gid3" )
    public void consume1(String message,
                        @Header(KafkaHeaders.OFFSET) long offset,
                        @Header(KafkaHeaders.GROUP_ID) String groupid) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka consumer group receiver 1 received message:" + order+" offset="+offset+" groupid= "+groupid);
        } catch (IOException e) {
            System.out.println("Kafka consumer group receiver 1 : Cannot convert : " + message+" to an Order object");
        }
    }

    @KafkaListener(topics = "new-order-topic", groupId = "gid3" )
    public void consume2(String message,
                         @Header(KafkaHeaders.OFFSET) long offset,
                         @Header(KafkaHeaders.GROUP_ID) String groupid) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka consumer group receiver 2 received message:" + order+" offset="+offset+" groupid= "+groupid);
        } catch (IOException e) {
            System.out.println("Kafka consumer group receiver 2 : Cannot convert : " + message+" to an Order object");
        }
    }
}
