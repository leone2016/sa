package producer;

public record Order(
        String orderNumber,
        String customerName,
        String customerCountry,
        double amount,
        String status
) {}
