package consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.kafka.annotation.KafkaListener;

import java.io.IOException;

@Service
public class KafkaConsumers {

    @KafkaListener(groupId = "gid1",
            topicPartitions = { @TopicPartition(topic = "new-order-topic2", partitions = { "0" })})
    public void consume(String message,
                         @Header(KafkaHeaders.OFFSET) long offset,
                         @Header(KafkaHeaders.RECEIVED_PARTITION) int partition) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka consumer 1 received message:" + order+" offset="+offset+" partition= "+partition);
        } catch (IOException e) {
            System.out.println("Kafka consumer 1 : Cannot convert : " + message+" to an Order object");
        }
    }

    @KafkaListener(groupId = "gid1",
            topicPartitions = { @TopicPartition(topic = "new-order-topic2", partitions = { "1" })})
    public void consume2(String message,
                        @Header(KafkaHeaders.OFFSET) long offset,
                        @Header(KafkaHeaders.RECEIVED_PARTITION) int partition) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka consumer 2 received message:" + order+" offset="+offset+" partition= "+partition);
        } catch (IOException e) {
            System.out.println("Kafka consumer 2 : Cannot convert : " + message+" to an Order object");
        }
    }
    @KafkaListener(groupId = "gid1",
            topicPartitions = { @TopicPartition(topic = "new-order-topic2", partitions = { "2" })})
    public void consume3(String message,
                        @Header(KafkaHeaders.OFFSET) long offset,
                        @Header(KafkaHeaders.RECEIVED_PARTITION) int partition) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka consumer 3 received message:" + order+" offset="+offset+" partition= "+partition);
        } catch (IOException e) {
            System.out.println("Kafka consumer 3 : Cannot convert : " + message+" to an Order object");
        }
    }
}
