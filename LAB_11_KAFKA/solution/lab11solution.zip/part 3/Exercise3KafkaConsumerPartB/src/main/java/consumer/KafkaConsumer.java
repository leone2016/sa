package consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.DltHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class KafkaConsumer {
    @RetryableTopic(attempts = "3",
            backoff = @Backoff(delay = 1000, multiplier = 2))
    @KafkaListener(topics = "new-order-topic", groupId = "gid2", properties = {"auto.offset.reset:earliest"} )
    public void consume(String message,
                        @Header(KafkaHeaders.OFFSET) long offset,
                        @Header(KafkaHeaders.GROUP_ID) String groupid) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        Order order = objectMapper.readValue(message, Order.class);
        System.out.println("Kafka receiver received message:" + order+" offset="+offset+" groupid= "+groupid);
    }

    @DltHandler
    public void listenDLT(String message, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, @Header(KafkaHeaders.OFFSET) long offset) {
        System.out.println("DLT Received = " + message + ", topic= " + topic + ", offset= " + offset);
    }
}
