package producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;


@Service
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private ObjectMapper objectMapper = new ObjectMapper();

    public void sendOrders() {
        List<Order> orders = List.of(
                new Order("ORD-001", "Alice", "USA", 120.5, "NEW"),
                new Order("ORD-002", "Bob", "UK", 300.0, "NEW"),
                new Order("ORD-003", "Charlie", "Germany", 450.25, "PROCESSING"),
                new Order("ORD-004", "Diana", "India", 220.75, "SHIPPED"),
                new Order("ORD-005", "Ethan", "Canada", 99.99, "DELIVERED"),
                new Order("ORD-006", "Alice", "USA", 120.5, "NEW"),
                new Order("ORD-007", "Bob", "UK", 300.0, "NEW"),
                new Order("ORD-008", "Charlie", "Germany", 450.25, "PROCESSING"),
                new Order("ORD-009", "Diana", "India", 220.75, "SHIPPED"),
                new Order("ORD-010", "Ethan", "Canada", 99.99, "DELIVERED"),
                new Order("ORD-011", "Alice", "USA", 120.5, "NEW"),
                new Order("ORD-012", "Bob", "UK", 300.0, "NEW"),
                new Order("ORD-013", "Charlie", "Germany", 450.25, "PROCESSING"),
                new Order("ORD-014", "Diana", "India", 220.75, "SHIPPED"),
                new Order("ORD-015", "Ethan", "Canada", 99.99, "DELIVERED")
        );

        orders.forEach(order -> {
            try {
                String orderAsString = objectMapper.writeValueAsString(order);
                kafkaTemplate.send("new-order-topic", order.orderNumber(), orderAsString);
                Thread.sleep(2000);
                System.out.println("sending order -"+order.orderNumber()+" at "+ LocalTime.now().getSecond());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}