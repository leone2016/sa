package consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalTime;
import java.util.List;

@Service
public class KafkaConsumer {

//    @KafkaListener(topics = "new-order-topic", groupId = "gid2" )
//    public void consume(String message,
//                        @Header(KafkaHeaders.OFFSET) long offset,
//                        @Header(KafkaHeaders.GROUP_ID) String groupid) {
//        ObjectMapper objectMapper = new ObjectMapper();
//        try {
//            Order order = objectMapper.readValue(message, Order.class);
//            System.out.println("Kafka receiver received message:" + order+" at "+ LocalTime.now().getSecond());
//        } catch (IOException e) {
//            System.out.println("Kafka receiver: Cannot convert : " + message+" to an Order object");
//        }
//    }

    @KafkaListener(topics = "new-order-topic", groupId = "gid2")
    public void consume(List<Message<String>> messages) {
        for(Message message: messages) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                Order order = objectMapper.readValue(message.getPayload().toString(), Order.class);
                System.out.println("Kafka receiver received message:" + order+" at "+ LocalTime.now().getSecond());
            } catch (IOException e) {
                System.out.println("Kafka receiver: Cannot convert : " + message+" to an Order object");
            }
        }
    }

}
