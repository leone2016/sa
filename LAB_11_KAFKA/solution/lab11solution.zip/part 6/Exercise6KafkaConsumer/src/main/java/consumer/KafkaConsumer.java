package consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.LocalTime;

@Service
public class KafkaConsumer {

    @Transactional
    @KafkaListener(topics = "new-order-topic", groupId = "gid2", properties = {"auto.offset.reset:earliest"} )
    public void consume(String message,
                        @Header(KafkaHeaders.OFFSET) long offset,
                        @Header(KafkaHeaders.GROUP_ID) String groupid) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka receiver received message:" + order+" offset="+offset+" Time received = "+ LocalTime.now());
        } catch (IOException e) {
            System.out.println("Kafka receiver earliest: Cannot convert : " + message+" to an Order object");
        }
    }
}
