package app;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
    private String receivedMessage="";


    @KafkaListener(topics = "topic1", groupId = "gid1")
    public void consume(String message) {
        System.out.println("Receiving message = " + message);
        receivedMessage = message;
    }

    public String getReceivedMessage() {
        return receivedMessage;
    }
}
