package app;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@EmbeddedKafka(topics = {"topic1"})
public class KafkaIntegrationTest {
    @Autowired
    private KafkaConsumer consumer;

    @Autowired
    private KafkaProducer producer;

    @Test
    void testKafka() throws JsonProcessingException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();
        Order sendOrder = new Order("ORD-001", "Alice", "USA", 120.5, "NEW");
        producer.sendOrder(sendOrder);
        Thread.sleep(4);
        Order receivedOrder = consumer.getReceivedOrder();
        assertThat(receivedOrder.equals(sendOrder));

    }
}
