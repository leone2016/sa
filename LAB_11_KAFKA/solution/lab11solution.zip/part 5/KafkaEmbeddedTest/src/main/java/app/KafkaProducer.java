package app;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private ObjectMapper objectMapper = new ObjectMapper();

    public void sendOrder(Order order) throws JsonProcessingException {

        String orderAsString = objectMapper.writeValueAsString(order);
        kafkaTemplate.send("ordertopic1", orderAsString);
        System.out.println("Send: " + order);

    }
}