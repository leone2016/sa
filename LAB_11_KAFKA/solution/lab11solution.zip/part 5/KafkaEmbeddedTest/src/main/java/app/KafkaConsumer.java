package app;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalTime;

@Service
public class KafkaConsumer {
    private Order receivedOrder = new Order("","","",0.0,"");


    @KafkaListener(topics = "ordertopic1", groupId = "gid1")
    public void consume(String message) {
        System.out.println("---------------------------------YES");
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Order order = objectMapper.readValue(message, Order.class);
            System.out.println("Kafka receiver received message:" + order+" Time received = "+ LocalTime.now());
            receivedOrder = order;
        } catch (IOException e) {
            System.out.println("Kafka receiver : Cannot convert : " + message+" to an Order object");
        }
    }

    public Order getReceivedOrder() {
        return receivedOrder;
    }
}
